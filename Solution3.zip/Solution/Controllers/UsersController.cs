using Solution.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Solution.Models;
namespace Solution.Controllers;
public class UsersController : Controller
{
    public readonly SolutionContext _Context;
    public UsersController(SolutionContext context)
    {
        _Context = context;
    }
    public async Task<IActionResult> Index()
    {
        return View(await _Context.Users.ToListAsync());
    }
    public async Task<IActionResult> Details(int? id)
    {
    return View(await _Context.Users.FirstOrDefaultAsync(m => m.Id == id));
    }

    public async Task<IActionResult> Create ([Bind("Names, LastNames, Nickname, Email, Phone")]User usuario){
      if(ModelState.IsValid){
      _Context.Users.Add(usuario);
      await _Context.SaveChangesAsync();
      return RedirectToAction("Index");
      }
    return View(usuario);
    }

    public async Task<IActionResult> Delete (int id){
      var  user = await _Context.Users.FindAsync(id);
      _Context.Users.Remove(user);
      await _Context.SaveChangesAsync();
      return RedirectToAction("Index");
    }

    
}