using Solution.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace Solution.Controllers;
public class UsersController : Controller
{
    public readonly SolutionContext _Context;
    public UsersController(SolutionContext context)
    {
        _Context = context;
    }
    public async Task<IActionResult> Index()
    {
        return View(await _Context.Users.ToListAsync());
    }
    public async Task<IActionResult> Details(int? id)
    {
    return View(await _Context.Users.FirstOrDefaultAsync(m => m.Id == id));
    }
}