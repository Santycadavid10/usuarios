using Microsoft.EntityFrameworkCore;
using Solution.Models;
namespace Solution.Data;
public class SolutionContext : DbContext
{
    public SolutionContext(DbContextOptions<SolutionContext> options) : base(options)
    {
    }
    public DbSet<User> Users { get; set; }
}