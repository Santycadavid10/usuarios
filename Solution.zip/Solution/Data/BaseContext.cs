using Microsoft.EntityFrameworkCore;
using Solution.Models;
namespace Solution.Data;
public class BaseContext : DbContext
{
    public BaseContext(DbContextOptions<BaseContext> options) : base(options)
    {
    }
    public DbSet<User> Users { get; set; }
}