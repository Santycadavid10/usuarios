using Solution.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace Solution.Controllers;
public class UsersController : Controller
{
    public readonly BaseContext _Context;
    public UsersController(BaseContext context)
    {
        _Context = context;
    }
    public async Task<IActionResult> Index()
    {
        return View(await _Context.Users.ToListAsync());
    }
}